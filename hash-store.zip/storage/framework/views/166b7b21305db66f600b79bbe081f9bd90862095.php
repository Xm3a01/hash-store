[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH F:\Projects\hash-store\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>