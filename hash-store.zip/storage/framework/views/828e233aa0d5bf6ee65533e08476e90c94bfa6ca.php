<?php echo e($slot); ?>

<?php /**PATH F:\Projects\hash-store\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/panel.blade.php ENDPATH**/ ?>