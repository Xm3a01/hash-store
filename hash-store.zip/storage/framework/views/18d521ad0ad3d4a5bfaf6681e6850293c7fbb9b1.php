<div class="sidebar">
    <nav class="sidebar-nav">
        <ul class="nav">
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('admins.dashboard')); ?>"><i class="icon-speedometer"></i> الصفحة الرئيسية </a>
            </li>

            <li class="nav-title">
                المحتويات
            </li>
            <li class="nav-item nav-dropdown">
                <?php if(Auth::guard('admin')->user()->is_supervisor): ?>
                  <a class="nav-link " href="<?php echo e(route('products.index')); ?>"><i class="icon-paypal"></i> المنتجات</a>
                <?php else: ?>
                    <a class="nav-link " href="<?php echo e(route('users.index')); ?>"><i class="icon-user"></i> المستخدمين</a>
                    <a class="nav-link " href="<?php echo e(route('admins.index')); ?>"><i class="icon-user"></i> مشرفين</a>
                    <a class="nav-link " href="<?php echo e(route('products.index')); ?>"><i class="icon-paypal"></i> المنتجات</a>
                    <a class="nav-link " href="<?php echo e(route('categories.index')); ?>"><i class="icon-tag"></i> التصنيفات</a>
                    <a class="nav-link " href="<?php echo e(route('orders.index')); ?>"><i class="icon-handbag"></i> الطالبات</a>
                <?php endif; ?>
              
            </li>

        </ul>
    </nav>
</div><?php /**PATH F:\Projects\hash-store\resources\views/admins/dashboard/_includes/sidebar.blade.php ENDPATH**/ ?>