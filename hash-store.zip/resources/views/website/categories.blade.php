@extends('layouts.app')

@section('content')
<vue-category />  
@endsection