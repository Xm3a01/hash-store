<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>HashZo </title>

    <!-- Google font -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700" rel="stylesheet">

    <!-- Bootstrap -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('vendor/website/css/bootstrap.min.css')); ?>"/>

    <!-- Slick -->
    

    <!-- nouislider -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('vendor/website/css/nouislider.min.css')); ?>"/>

    <!-- Font Awesome Icon -->
    <link rel="stylesheet" href="<?php echo e(asset('vendor/website/css/font-awesome.min.css')); ?>">

    <!-- Custom stlylesheet -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('vendor/website/css/style.css')); ?>"/>
</head>
<body>
<div id="app">
    <?php echo $__env->yieldContent('content'); ?>
</div>

    <script src="<?php echo e(asset('vendor/website/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/website/js/bootstrap.min.js')); ?>"></script>
    
    
    <script src="<?php echo e(asset('vendor/website/js/main.js')); ?>"></script>
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
    <script>
        $('.alert').alert()
    </script>
</body>
</html>
<?php /**PATH F:\Projects\hash-store\resources\views/layouts/app.blade.php ENDPATH**/ ?>