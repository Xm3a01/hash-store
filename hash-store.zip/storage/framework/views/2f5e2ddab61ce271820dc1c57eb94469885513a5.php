
<!-- Bootstrap and necessary plugins -->
<script src="<?php echo e(asset('vendor/js/libs/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/libs/tether.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/libs/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/libs/pace.min.js')); ?>"></script>

<!-- Plugins and scripts required by all views -->
<script src="<?php echo e(asset('vendor/js/libs/Chart.min.js')); ?>"></script>

<!-- CoreUI main scripts -->

<script src="<?php echo e(asset('vendor/js/app.js')); ?>"></script>

<!-- Plugins and scripts required by this views -->
<!-- Custom scripts required by this view -->
<script src="<?php echo e(asset('vendor/js/views/main.js')); ?>"></script>

<script src="<?php echo e(asset('vendor/js/toastr.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendor/js/ui-toastr.min.js')); ?>" type="text/javascript"></script>
<!-- Grunt watch plugin -->
<?php /**PATH F:\Projects\hash-store\resources\views/admins/dashboard/_includes/scripts.blade.php ENDPATH**/ ?>