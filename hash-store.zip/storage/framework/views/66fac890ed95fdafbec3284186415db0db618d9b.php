 <!-- Icons -->
 <link href="<?php echo e(asset('/vendor/css/font-awesome.min.css')); ?>" rel="stylesheet">
 <link href="<?php echo e(asset('/vendor/css/simple-line-icons.css')); ?>" rel="stylesheet">
 <!-- Main styles for this application -->
 <link href="<?php echo e(asset('/vendor/dest/style.css')); ?>" rel="stylesheet">
 <link href="<?php echo e(asset('vendor/css/toastr-rtl.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php /**PATH F:\Projects\hash-store\resources\views/admins/dashboard/_includes/styles.blade.php ENDPATH**/ ?>